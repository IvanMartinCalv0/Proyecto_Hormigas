package Logica;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LogCreator {
    private FileWriter salida;
    private Lock cerrojo = new ReentrantLock();
    
    public LogCreator(){
        try {
            this.salida = new FileWriter("evolucionColonia.txt");
            salida.close();
        } catch (IOException ex) {
            Logger.getLogger(LogCreator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void añadir_aLog(String s){
        cerrojo.lock();
        try {
            Date date = new Date();
            salida = new FileWriter("evolucionColonia.txt", true);
            salida.write(date.toString()+" " + s + "\n");
            salida.close();
        } catch (IOException ex) {
            Logger.getLogger(LogCreator.class.getName()).log(Level.SEVERE, null, ex);
        }finally{cerrojo.unlock();}
    }
}
