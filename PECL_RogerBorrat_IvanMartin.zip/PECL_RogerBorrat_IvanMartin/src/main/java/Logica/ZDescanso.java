package Logica;

import javax.swing.JTextField;

public class ZDescanso {
    private ListaHormigas lista;
    private Amenaza a;
    
    public ZDescanso(JTextField j, Amenaza a) {
        this.lista = new ListaHormigas(j);
        this.a = a;
    }
    
    public void descansar(int n, String id){
        
        lista.añadir(id);
        try {
            Thread.sleep(n);
        } catch (InterruptedException ex) {
            lista.quitar(id);
            if(Character.compare(id.charAt(1),'S')==0) {   
                a.repeler(id);    
            }else{
                a.refugiar(id);
            }
            lista.añadir(id);
        }
        lista.quitar(id);
    }
}
