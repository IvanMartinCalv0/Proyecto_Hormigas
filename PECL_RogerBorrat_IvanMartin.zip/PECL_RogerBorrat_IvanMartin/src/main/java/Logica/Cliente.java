package Logica;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JTextField;


public class Cliente extends Thread {
    private JTextField extCol;
    private JTextField intCol;
    private JTextField hacInst;
    private JTextField repeliendo;
    private JTextField criaCom;
    private JTextField criaRef;
    private boolean amenaza = false;
    private JButton botAmenaza;

    public Cliente(JTextField extCol, JTextField intCol, JTextField hacInst, JTextField repeliendo, JTextField criaCom, JTextField criaRef, JButton botAmenaza) {
        this.extCol = extCol;
        this.intCol = intCol;
        this.hacInst = hacInst;
        this.repeliendo = repeliendo;
        this.criaCom = criaCom;
        this.criaRef = criaRef;
        extCol.setText("0");
        intCol.setText("0");
        hacInst.setText("0");
        repeliendo.setText("0");
        criaCom.setText("0");
        criaRef.setText("0");
        this.botAmenaza = botAmenaza;
    }
    
    @Override
    public void run(){
      while(true)
      {
          try
          {
            InterfaceColonia obj = (InterfaceColonia) Naming.lookup("//127.0.0.1/ObjetoColonia");
            extCol.setText(String.valueOf(obj.obExterior()));
            intCol.setText(String.valueOf(obj.obInterior()));
            hacInst.setText(String.valueOf(obj.solInstruccion()));
            repeliendo.setText(String.valueOf(obj.solInvasion()));
            criaCom.setText(String.valueOf(obj.criZonaCom()));
            criaRef.setText(String.valueOf(obj.criRefugio()));
            if(obj.pasarAmenaza()){
                botAmenaza.setVisible(false);
            }else if(amenaza){
                botAmenaza.setVisible(false);
                obj.causarAmenaza();
                amenaza = false;
            }else{
                botAmenaza.setVisible(true);
            }
            Thread.sleep(100);
          } catch (NotBoundException | MalformedURLException | RemoteException | InterruptedException ex) {
              Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
          }
      }
    }

    public void setAmenaza(boolean amenaza) {
        this.amenaza = amenaza;
    }
    
}
