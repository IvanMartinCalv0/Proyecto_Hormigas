package Logica;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;


public class Almacen {
    private int total;
    private Semaphore entrar;
    private Semaphore em;
    private ListaHormigas lista;
    private JTextField j;
    
    public Almacen(JTextField j1, JTextField j2) {
        total = 0;
        entrar = new Semaphore(10, true);
        em = new Semaphore(1);
        this.j = j2;
        j.setText(String.valueOf(total));
        lista = new ListaHormigas(j1);
    }
       
    public void depositar(String id){
        try{
            entrar.acquire();
            lista.añadir(id);
            Thread.sleep(2000 + (int)(Math.random()*2000));
            em.acquire();
            total+=5;
            j.setText(String.valueOf(total));
            em.release();
            lista.quitar(id);
            entrar.release();
            liberar();
        }catch(InterruptedException e){System.out.println("ERROR");}
        
    }
    
    public void cogerComida(String id){
        try {
            entrar.acquire();
            lista.añadir(id);
            Thread.sleep(1000 + (int)(Math.random()*1000));
            esperar();
            em.acquire();
            total-=5;
            j.setText(String.valueOf(total));
            em.release();
            entrar.release();
            lista.quitar(id);
        } catch (InterruptedException ex) {
            Logger.getLogger(Almacen.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public synchronized void esperar(){
        while(total<5){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Almacen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public synchronized void liberar(){
        notify();
    }
}
