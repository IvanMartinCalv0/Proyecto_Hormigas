package Logica;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ClaseDetener {
    private Boolean detener = false;
    
    public synchronized void esperar(){
        
        while(detener){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(ClaseDetener.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void detener(){
        detener = true;
    }
    
    public synchronized void reanudar(){
        detener = false;
        notifyAll();
    }
    
}
