package Logica;

public class Hormiga_Cria extends Thread{
    private String id;
    private Hormiguero hormiguero;
    private ZDescanso zdescanso;
    private ZComer zcomer;
    private ClaseDetener cd;
    private Amenaza a;
    private LogCreator lc;

    public Hormiga_Cria(String id, Hormiguero h, ZDescanso z1, ZComer z2, ClaseDetener cd, Amenaza a, LogCreator lc) {
        this.id = id;
        this.hormiguero = h;
        this.zdescanso = z1;
        this.zcomer = z2;
        this.cd = cd;
        this.a = a;
        this.lc = lc;
    }
    
    @Override
    public void run(){
        a.añadir_cria(this);
        lc.añadir_aLog("Se ha generado la hormiga: "+id);
        hormiguero.entrar(id);
        lc.añadir_aLog(id + " ha entrado al hormiguero");
        if(a.getAmenaza()){
            a.refugiar(id);
        }
        cd.esperar();
        while(true){
            zcomer.cogerComida(id);
            lc.añadir_aLog(id + " coge comida");
            cd.esperar();
            zcomer.comer(3000+(int)(Math.random()*2000), id);
            lc.añadir_aLog(id + " ha comido");
            cd.esperar();
            zdescanso.descansar(4000, id);
            lc.añadir_aLog(id + " ha descansado");
            cd.esperar();
        }
    }
}
