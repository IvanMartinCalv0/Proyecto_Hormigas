package Logica;

import javax.swing.JTextField;

public class ZInstruccion {
    private ListaHormigas lista ;
    private Amenaza a;
    private int solInst = 0;
    
    public synchronized void incrementarSolI(){
        solInst++;
    }
    
    public synchronized void decrementarSolI(){
        solInst--;
    }

    public ZInstruccion(JTextField j, Amenaza a) {
        lista = new ListaHormigas(j);
        this.a = a;
    }
    
    public void hacer_Instruccion(String id){
        lista.añadir(id);
        incrementarSolI();
        try {
            Thread.sleep(2000+(int)(6000*Math.random()));
            decrementarSolI();
        } catch (InterruptedException ex) {
            decrementarSolI();
            lista.quitar(id);
            a.repeler(id);
            lista.añadir(id);
        }
        lista.quitar(id);
    }

    public int getSolInst() {
        return solInst;
    }
    
    
}
