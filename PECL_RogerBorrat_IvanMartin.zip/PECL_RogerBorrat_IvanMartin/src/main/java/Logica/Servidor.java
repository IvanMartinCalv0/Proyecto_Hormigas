package Logica;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;



public class Servidor extends Thread{
    private Amenaza am;
    private Hormiguero h;
    private Refugio r;
    private ZComer zc;
    private ZInstruccion zi;

    public Servidor(Amenaza am, Hormiguero h, Refugio r, ZComer zc, ZInstruccion zi){
        this.am = am;
        this.h = h;
        this.r = r;
        this.zc = zc;
        this.zi = zi;
    }
    
    @Override
    public void run(){
        
        try {
            Colonia obj = new Colonia(am,h,r,zc,zi);
            Registry registry = LocateRegistry.createRegistry(1099);
            Naming.rebind("//localhost/ObjetoColonia", obj);
        } catch (RemoteException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
}
