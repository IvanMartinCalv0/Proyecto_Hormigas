package Logica;

public class CreadorHormigas extends Thread{
    private Almacen a ;
    private Hormiguero h;
    private Refugio r;
    private ZComer c;
    private ZDescanso d;
    private ZInstruccion i;
    private ClaseDetener cd;
    private Amenaza am;
    private LogCreator lc;
    

    public CreadorHormigas(Almacen a, Hormiguero h, Refugio r, ZComer c, ZDescanso d, ZInstruccion i, ClaseDetener cd, Amenaza am, LogCreator lc) {
        this.a = a;
        this.h = h;
        this.r = r;
        this.c = c;
        this.d = d;
        this.i = i;
        this.cd = cd;
        this.am = am;
        this.lc = lc;
    }
    
    public String num_ceros(String id){
        int len = id.length();
        int ceros = 4-len;
        String res ="";
        for(int i = 0; i<ceros;i++){
            res+="0";
        }
        res+=id;
        return res;
    }
    
    public void run(){
        
        int cont_o = 1;
        int cont_s = 1;
        int cont_c = 1;
        try{
            for(int j = 0; j<2000 ; j++){
                for(int k = 0; k<3 ;k++){
                    Hormiga_Obrera o = new Hormiga_Obrera("HO" + num_ceros(String.valueOf(cont_o)), h, d, c, a, cont_o, cd, lc);
                    o.start();
                    cont_o++;
                    cd.esperar();
                    Thread.sleep(800 + (int)(Math.random()*2700));
                }
                Hormiga_Soldado s = new Hormiga_Soldado("HS" + num_ceros(String.valueOf(cont_s)), h, d, c, i, cd, am, lc);
                s.start();
                cont_s++;
                cd.esperar();
                Thread.sleep(800 + (int)(Math.random()*2700));
                Hormiga_Cria c1 = new Hormiga_Cria("HC" + num_ceros(String.valueOf(cont_c)), h, d, c, cd, am, lc);
                c1.start();
                cont_c++;
                cd.esperar();
                Thread.sleep(800 + (int)(Math.random()*2700));
            }
        }catch(InterruptedException e){System.out.println(e);}
       
    }
}
