package Logica;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceColonia extends Remote {
    int obExterior() throws RemoteException;
    int obInterior() throws RemoteException;
    int solInstruccion() throws RemoteException;
    int solInvasion() throws RemoteException;
    int criZonaCom() throws RemoteException;
    int criRefugio() throws RemoteException;
    void causarAmenaza() throws RemoteException;
    boolean pasarAmenaza() throws RemoteException;
}
