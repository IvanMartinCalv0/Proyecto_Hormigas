package Logica;

import java.util.ArrayList;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Amenaza {
    private ArrayList<Hormiga_Soldado> hs = new ArrayList<>();
    private ArrayList<Hormiga_Cria> hc = new ArrayList<>();
    private ListaHormigas soldados;
    private Boolean amenaza = false;
    private CyclicBarrier c;
    private JButton jb;
    private Hormiguero h;
    private Refugio r;
    private LogCreator lc;
    private JLabel txtEspera;
    private int solRep = 0;
    
    public synchronized void incrementarSolR(){
        solRep++;
    }
    
    public synchronized void decrementarSolR(){
        solRep--;
    }
    
    
    public Amenaza(JButton jb, JTextField jtf, Hormiguero h, Refugio r, LogCreator lc, JLabel txtEsp){
        this.jb = jb;
        soldados =  new ListaHormigas(jtf);
        this.h = h;
        this.r = r;
        this.lc = lc;
        this.txtEspera = txtEsp;
    }
    
    public synchronized void añadir_soldado(Hormiga_Soldado h){
        hs.add(h);
    }
    
    public synchronized void añadir_cria(Hormiga_Cria h){
        hc.add(h);
    }
    
    public void repeler(String id){
        try {
            lc.añadir_aLog(id + " va a repeler la amenaza");
            h.salir();
            soldados.añadir(id);
            incrementarSolR();
            c.await();
            txtEspera.setText("Peleando");
            Thread.sleep(20*1000);
            Thread.currentThread().interrupted(); 
            soldados.quitar(id);
            decrementarSolR();
            if(soldados.getLista().isEmpty()){
                jb.setVisible(true);
                amenaza = false;
                despertarCrias();
                lc.añadir_aLog("SE HA REPELIDO LA AMENAZA!!! :)");
                txtEspera.setText("   ");
            }
            h.entrar(id);
            lc.añadir_aLog(id + " ha repelido la amenaza");
        } catch (InterruptedException ex) {
            Logger.getLogger(Amenaza.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BrokenBarrierException ex) {
            Logger.getLogger(Amenaza.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Boolean getAmenaza() {
        return amenaza;
    }
    
    public synchronized void despertarCrias(){
        notifyAll();
    }
     
    public synchronized void dormir(){
        while(amenaza){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Amenaza.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void refugiar(String id){
        r.irRefugio(id);
        lc.añadir_aLog(id + " ha llegado al refugio por la amenaza");
        dormir();
        r.salirRefugio(id);
        lc.añadir_aLog(id + " ha salido del refugio");
        Thread.currentThread().interrupted(); 
    }
    
    
    public void amenaza(){
        try{
            lc.añadir_aLog("HAY UNA AMENAZA!!! :(");
            amenaza = true;
            jb.setVisible(false);
            int tam = hs.size();
            c = new CyclicBarrier(tam);
            for(int i = 0; i < tam ; i++){
                hs.get(i).interrupt();

            } 
            txtEspera.setText("Esperando Soldados");
            tam = hc.size();
            for(int i = 0; i<tam ; i++){
                hc.get(i).interrupt();
            }
        }catch(Exception e){
            jb.setVisible(true);
        }
    }

    public int getSolRep() {
        return solRep;
    }
    
    
}
