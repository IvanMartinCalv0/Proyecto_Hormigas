package Logica;

public class Hormiga_Soldado extends Thread{
    private ZInstruccion zinst;
    private String id;
    private Hormiguero hormiguero;
    private ZDescanso zdescanso;
    private ZComer zcomer;
    private ClaseDetener cd;
    private Amenaza a;
    private LogCreator lc;
    
    public Hormiga_Soldado(String id, Hormiguero h, ZDescanso z1, ZComer z2, ZInstruccion z, ClaseDetener cd, Amenaza a, LogCreator lc) {
        this.id = id;
        this.hormiguero = h;
        this.zdescanso = z1;
        this.zcomer = z2;
        this.zinst = z;
        this.cd = cd;
        this.a = a;
        this.lc = lc;
    }
    
    @Override
    public void run(){
        int cont = 0;
        lc.añadir_aLog("Se ha generado la hormiga: "+id);
        a.añadir_soldado(this);
        hormiguero.entrar(id);
        lc.añadir_aLog(id + " ha entrado al hormiguero");
        cd.esperar();
        while(true){
            if(cont == 6){
                zcomer.cogerComida(id);
                lc.añadir_aLog(id + " ha cogido comida de la zona para comer");
                cd.esperar();
                zcomer.comer(3000, id);
                lc.añadir_aLog(id + " ha comido");
                cd.esperar();
                cont = 0;
            }else{
                zinst.hacer_Instruccion(id);
                lc.añadir_aLog(id + " ha hecho la instruccion");
                cd.esperar();
                zdescanso.descansar(2000, id);
                lc.añadir_aLog(id + " ha descansado");
                cont++;
                cd.esperar();
            }
        }
    }
    
    
}
