package Logica;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

public class Hormiguero {
    private Semaphore entrada;
    private Semaphore salida;
    private ListaHormigas lista;
    private ListaHormigas caminoZcomer;
    private Amenaza amenaza;
    private int obfuera = 0;
    private int obdentro = 0;

    public Hormiguero(JTextField j1, JTextField j2, Amenaza am) {
        entrada = new Semaphore(1, true);
        salida = new Semaphore(2, true);
        lista = new ListaHormigas(j1);
        caminoZcomer = new ListaHormigas(j2);
        this.amenaza = am;
    }
    
    public synchronized void incrementarObF(){
        obfuera++;
    }
    
    public synchronized void incrementarObD(){
        obdentro++;
    }
    
    public synchronized void decrementarObF(){
        obfuera--;
    }
    
    public synchronized void decrementarObD(){
        obdentro--;
    }
    
    public void entrar(String id){
        try {
            entrada.acquire();
            Thread.sleep(100);
            entrada.release();
        } catch (InterruptedException ex) {
            
            if(Character.compare(id.charAt(1),'S')==0) {   
                amenaza.repeler(id);    
            }else{
                amenaza.refugiar(id);
            }
           
        }
    }
    
    public void salir(){
        try {
            salida.acquire();
            Thread.sleep(100);
            salida.release();
        } catch (InterruptedException ex) {
            Logger.getLogger(Hormiguero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cogerComida(String id){
        try {
            lista.añadir(id);
            Thread.sleep(3900); //Los otros 100ms restantes son del tiempo en el tunel
            lista.quitar(id);
        } catch (InterruptedException ex) {
            Logger.getLogger(Hormiguero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void irZComer(String id){
        try {
            caminoZcomer.añadir(id);
            Thread.sleep(1000 + (int)(Math.random()*2000));
            caminoZcomer.quitar(id);
        } catch (InterruptedException ex) {
            Logger.getLogger(Hormiguero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int getObfuera() {
        return obfuera;
    }

    public int getObdentro() {
        return obdentro;
    }
    
    
    
}
