package Logica;

public class Hormiga_Obrera extends Thread{
    private Almacen almacen;
    private String id;
    private Hormiguero hormiguero;
    private ZDescanso zdescanso;
    private ZComer zcomer;
    private int n;
    private ClaseDetener cd;
    private LogCreator lc;

    public Hormiga_Obrera(String id, Hormiguero h, ZDescanso z1, ZComer z2, Almacen a, int n, ClaseDetener cd, LogCreator lc) {
        this.id = id;
        this.hormiguero = h;
        this.zdescanso = z1;
        this.zcomer = z2;
        this.almacen = a;
        this.n = n;
        this.cd = cd;
        this.lc = lc;
    }
    
    @Override
    public void run(){
        int cont = 0;
        lc.añadir_aLog("Se ha generado la hormiga: "+id);
        hormiguero.incrementarObF();
        hormiguero.entrar(id);
        hormiguero.decrementarObF();
        hormiguero.incrementarObD();
        lc.añadir_aLog(id + " ha entrado al hormiguero");
        cd.esperar();
        while (true){
            if(cont==10){
                zcomer.cogerComida(id);
                lc.añadir_aLog(id + " ha cogido comida");
                cd.esperar();
                zcomer.comer(3000, id);
                lc.añadir_aLog(id + " ha comido");
                cd.esperar();
                zdescanso.descansar(1000, id);
                lc.añadir_aLog(id + " ha descansado");
                cont=0;
                cd.esperar();
            }else{
                if(n%2==1){
                    hormiguero.salir();
                    hormiguero.decrementarObD();
                    hormiguero.incrementarObF();
                    lc.añadir_aLog(id + " ha salido del hormiguero");
                    cd.esperar();
                    hormiguero.cogerComida(id);
                    lc.añadir_aLog(id + " ha recogido comida del exterior");
                    cd.esperar();
                    hormiguero.entrar(id);
                    hormiguero.decrementarObF();
                    hormiguero.incrementarObD();
                    lc.añadir_aLog(id + " ha entrado al hormiguero");
                    cd.esperar();
                    almacen.depositar(id);
                    lc.añadir_aLog(id + " ha guardado la comida en el almacen");
                    cd.esperar();
                }else{
                    almacen.cogerComida(id);
                    lc.añadir_aLog(id + " ha cogido comida del almacen");
                    cd.esperar();
                    hormiguero.irZComer(id);
                    lc.añadir_aLog(id + " ha ido a la zona para comer");
                    cd.esperar();
                    zcomer.depositar(id);
                    lc.añadir_aLog(id + " ha dejado la comida");
                    cd.esperar();
                }cont++;
            }
        }
    }
    
    
}
