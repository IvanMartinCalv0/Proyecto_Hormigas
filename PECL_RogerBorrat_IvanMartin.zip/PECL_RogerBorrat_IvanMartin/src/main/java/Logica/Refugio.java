package Logica;

import javax.swing.JTextField;

public class Refugio {
    private ListaHormigas lista ;
    private int criaRef = 0;
    
    public Refugio(JTextField j) {
        lista = new ListaHormigas(j);
    }
    
    public synchronized void incrementarCriaR(){
        criaRef++;
    }
    
    public synchronized void decrementarCriaR(){
        criaRef--;
    }
    
    public void irRefugio(String id){
        incrementarCriaR();
        lista.añadir(id);
    }
    
    public void salirRefugio(String id){
        lista.quitar(id);
        decrementarCriaR();
    }

    public int getCriaRef() {
        return criaRef;
    }
    
}
