package Logica;

import java.util.ArrayList;
import javax.swing.JTextField;

public class ListaHormigas {
    private JTextField j;
    private ArrayList<String> lista;
    
    public ListaHormigas(JTextField j){
        this.j = j;
        lista = new ArrayList<>();
    }
    
    
    public synchronized void añadir(String s){
        lista.add(s);
        String text = j.getText();
        j.setText(text + s + ", ");
    }
    
    public synchronized void quitar(String s){
        lista.remove(s);
        String text = "";
        for(int i = 0; i < lista.size(); i++){
            text+= lista.get(i);
            text+=", ";
            
        }
        j.setText(text);
    }
    
    public synchronized ArrayList<String> getLista(){
        return lista;
    }
}
