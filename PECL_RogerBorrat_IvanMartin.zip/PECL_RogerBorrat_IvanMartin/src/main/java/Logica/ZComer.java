package Logica;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.swing.JTextField;


public class ZComer {
    private int comida;
    private Lock cerrojo;
    private Condition vacio;
    private ListaHormigas lista;
    private JTextField j;
    private Amenaza a;
    private int criaZcomer = 0;
    
    public synchronized void incrementarCriaZC(){
        criaZcomer++;
    }
    
    public synchronized void decrementarCriaZC(){
        criaZcomer--;
    }

    public ZComer(JTextField j1, JTextField j2, Amenaza a) {
        comida = 0;
        cerrojo = new ReentrantLock();
        vacio = cerrojo.newCondition();
        this.j = j2;
        j.setText(String.valueOf(comida));
        lista = new ListaHormigas(j1);
        this.a = a;
    }
    
    public void depositar(String id){
        lista.añadir(id);
        cerrojo.lock();
        try{
            Thread.sleep(1000 + (int)(Math.random()*1000));
            comida += 5;
            j.setText(String.valueOf(comida));
            vacio.signalAll();
        }catch(InterruptedException e){System.out.println("ERROR");
        }finally{cerrojo.unlock();}
        lista.quitar(id);
    }
    
    public void cogerComida(String id){
        lista.añadir(id);
        if(Character.compare(id.charAt(1),'C')==0) {   
            incrementarCriaZC();   
        }
        cerrojo.lock();
        try {
            while(comida<=0){
                vacio.await();
            }
            comida --;
            j.setText(String.valueOf(comida));
            vacio.signalAll();
        } catch (InterruptedException ex) {
            lista.quitar(id);
            if(Character.compare(id.charAt(1),'S')==0) {   
                a.repeler(id);    
            }else{
                decrementarCriaZC();   
                a.refugiar(id);
            }
            lista.añadir(id);
        } finally {
            cerrojo.unlock();
        }
        
    }
    
    public void comer(int n, String id){
        try {
            Thread.sleep(n);
            lista.quitar(id);
            if(Character.compare(id.charAt(1),'C')==0) {   
                decrementarCriaZC();   
            }
        } catch (InterruptedException ex) {
            lista.quitar(id);
            if(Character.compare(id.charAt(1),'S')==0) {   
                a.repeler(id);    
            }else{
               decrementarCriaZC();
               a.refugiar(id);
            }
            lista.añadir(id);
        }
    }

    public int getCriaZcomer() {
        return criaZcomer;
    }
    
    
    
}
