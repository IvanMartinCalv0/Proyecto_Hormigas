package Logica;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


public class Colonia extends UnicastRemoteObject implements InterfaceColonia{
    private Amenaza am;
    private Hormiguero h;
    private Refugio r;
    private ZComer zc;
    private ZInstruccion zi;

    public Colonia(Amenaza am, Hormiguero h, Refugio r, ZComer zc, ZInstruccion zi) throws RemoteException {
        this.am = am;
        this.h = h;
        this.r = r;
        this.zc = zc;
        this.zi = zi;
    }
    
    @Override
    public int obExterior() throws RemoteException{
        return h.getObfuera();
    }
    
    @Override
    public int obInterior() throws RemoteException{
        return h.getObdentro();
    }
    
    @Override
    public int solInstruccion() throws RemoteException{
        return zi.getSolInst();
    }
    
    @Override
    public int solInvasion() throws RemoteException{
        return am.getSolRep();
    }
    
    @Override
    public int criZonaCom() throws RemoteException{
        return zc.getCriaZcomer();
    }
    
    @Override
    public int criRefugio() throws RemoteException{
        return r.getCriaRef();
    }
    
    @Override
    public void causarAmenaza() throws RemoteException{
        am.amenaza();
    }
    
    @Override
    public boolean pasarAmenaza() throws RemoteException{
        return am.getAmenaza();
    }
}
